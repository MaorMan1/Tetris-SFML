====================================
        TETRIS REMAKE - by Maor Man
====================================

📦 CONTENTS:
-----------
- TetrisSFML.exe         <- The game executable
- /resources/            <- Game assets (textures, music, fonts, etc.)

🚀 HOW TO PLAY:
-------------
1. Extract the ZIP file anywhere you want.
2. Run `TetrisSFML.exe`.
3. ***Make sure the `resources` folder and other dll files stays in the same directory as the `.exe`.***

🕹️ GAME FEATURES:
----------------
- Classic Tetris gameplay
- Metal remix of the iconic Tetris theme
- Line clear animations
- Leaderboard system
- Pixel art UI with custom buttons

🎵 Music Credit

- Gameplay music: 
- **TETRIS - Theme A || Metal Cover by RichaadEB**
  [Watch on YouTube](https://www.youtube.com/watch?v=B631nbUJXsI&list=RDB631nbUJXsI&start_radio=1)

Used under fair use for educational and non-commercial purposes.

🔧 REQUIREMENTS:
---------------
- Windows 10 or later (64-bit)

📩 CONTACT:
----------
Created by Maor Man – 2025  
Feel free to reach out for feedback or suggestions!
